import { NavLink } from 'react-router-dom';
import { Home, User, Briefcase, Code2, GraduationCap, Mail } from 'lucide-react';
import { motion } from 'framer-motion';

const Sidebar = () => {
  const navItems = [
    { path: '/', icon: <Home size={20} />, label: 'Home' },
    { path: '/about', icon: <User size={20} />, label: 'About' },
    { path: '/experience', icon: <Briefcase size={20} />, label: 'Experience' },
    { path: '/skills', icon: <Code2 size={20} />, label: 'Skills' },
    { path: '/education', icon: <GraduationCap size={20} />, label: 'Education' },
    { path: '/contact', icon: <Mail size={20} />, label: 'Contact' },
  ];

  return (
    <motion.aside
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      className="w-16 bg-[#1a1443] min-h-screen fixed left-0 top-0 flex flex-col items-center py-6 z-50"
    >
      <nav className="flex flex-col items-center space-y-6">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `p-2 rounded-lg transition-all duration-300 ${
                isActive
                  ? 'bg-gradient-to-r from-pink-500 to-violet-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-[#2a2463]'
              }`
            }
            title={item.label}
          >
            {item.icon}
          </NavLink>
        ))}
      </nav>
    </motion.aside>
  );
}

export default Sidebar;