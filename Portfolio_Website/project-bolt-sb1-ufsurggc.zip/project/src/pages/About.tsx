import { motion } from 'framer-motion';

const About = () => {
  return (
    <section className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="grid sm:grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12"
      >
        <motion.div
          initial={{ x: -50 }}
          animate={{ x: 0 }}
          transition={{ delay: 0.2 }}
          className="sm:order-2 lg:order-1"
        >
          <p className="font-medium mb-5 text-[#16f2b3] text-xl uppercase">Who I am?</p>
          <p className="text-gray-200 sm:text-sm lg:text-lg">
            Hi! Myself Mujtaba Sohail Dar. I am a professional Front End developer with more than 2 years of
            experience. I have completed many projects and have a great knowledge about that. High attention
            to detail and being punctual are my specialty. I love almost all the stacks of web application
            development and love to make the web more open to the world. I always focus on building long-term
            relationships with all my clients by delivering the work as requested at a competitive price. So
            you will never feel any worries working with me.
          </p>
        </motion.div>
        <motion.div
          initial={{ x: 50 }}
          animate={{ x: 0 }}
          transition={{ delay: 0.3 }}
          className="flex justify-center sm:order-1 lg:order-2"
        >
          <img
            alt="Profile"
            loading="lazy"
            width="280"
            height="280"
            className="rounded-lg transition-all duration-1000 hover:scale-110 cursor-pointer"
            src="https://dl.dropboxusercontent.com/scl/fi/gygp9fnang85zza5pzygz/profile-pic.jpeg?rlkey=rc8twl1e68wt6zx0p32iqxn9m&st=bvc461c1&dl=0"
          />
        </motion.div>
      </motion.div>
    </section>
  );
};

export default About;