import { motion } from 'framer-motion';
import { Github, Linkedin, Facebook, Code2 } from 'lucide-react';

const Home = () => {
  return (
    <section className="relative flex flex-col items-center justify-center py-4 lg:py-12 my-12 ml-20">
      <img
        alt="Hero"
        loading="lazy"
        className="absolute -top-[98px] -z-10"
        src="https://mughis.vercel.app/hero.svg"
      />
      
      <div className="grid sm:grid-cols-1 lg:grid-cols-2 lg:gap-12 gap-y-8 mx-auto container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="order-2 lg:order-1 flex flex-col justify-center p-2 pb-20 md:pb-10 lg:pt-10"
        >
          <h1 className="text-3xl font-bold leading-10 text-white md:font-extrabold lg:text-[2.6rem] lg:leading-[3.5rem]">
            Hello, <br />
            This is <span className="text-pink-500">Mujtaba Sohail Dar</span>, I'm a Professional{' '}
            <span className="text-[#16f2b3]">React Developer</span>.
          </h1>
          
          <div className="my-12 flex items-center gap-5">
            <SocialLink href="https://github.com/MDar123" icon={<Github size={30} />} />
            <SocialLink href="https://www.linkedin.com/in/mujtaba-sohail-dar-27937b280" icon={<Linkedin size={30} />} />
            <SocialLink href="https://www.facebook.com/mujtaba.dar.129" icon={<Facebook size={30} />} />
            <SocialLink href="https://leetcode.com/u/ag9oGt3hh8" icon={<Code2 size={30} />} />
          </div>

          <div className="buttons flex gap-2 flex-wrap">
            <Button href="/contact">Contact Me</Button>
            <Button>Get Resume</Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="sm:order-1 lg:order-2 from-[#0d1224] border-[#1b2c68a0] relative rounded-lg border bg-gradient-to-r to-[#0a0d37]"
        >
          {/* Code snippet component here - same as your original but with React syntax */}
        </motion.div>
      </div>
    </section>
  );
};

const SocialLink = ({ href, icon }) => (
  <a
    target="_blank"
    rel="noopener noreferrer"
    className="transition-all text-pink-500 hover:scale-125 duration-300"
    href={href}
  >
    {icon}
  </a>
);

const Button = ({ href, children }) => (
  <button className="px-6 py-3 bg-gradient-to-r from-pink-500 to-violet-600 rounded-lg text-white hover:scale-105 transition-all duration-300">
    {children}
  </button>
);

export default Home;